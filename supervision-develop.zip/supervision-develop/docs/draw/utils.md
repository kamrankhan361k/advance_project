## draw_line

:::supervision.draw.utils.draw_line

## draw_rectangle

:::supervision.draw.utils.draw_rectangle

## draw_filled_rectangle

:::supervision.draw.utils.draw_filled_rectangle

## draw_polygon

:::supervision.draw.utils.draw_polygon

## draw_text

:::supervision.draw.utils.draw_text
