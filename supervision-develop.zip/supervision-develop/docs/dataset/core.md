!!! warning

    Dataset API is still fluid and may change. If you use Dataset API in your project until further notice, freeze the
    `supervision` version in your `requirements.txt` or `setup.py`.

## DetectionDataset

:::supervision.dataset.core.DetectionDataset

## ClassificationDataset

:::supervision.dataset.core.ClassificationDataset
