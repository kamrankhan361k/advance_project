!!! warning

    Evaluation API is still fluid and may change. If you use Evaluation API in your project until further notice, freeze the
    `supervision` version in your `requirements.txt` or `setup.py`.

## ConfusionMatrix

:::supervision.metrics.detection.ConfusionMatrix

## MeanAveragePrecision

:::supervision.metrics.detection.MeanAveragePrecision
