## box_iou_batch

:::supervision.detection.utils.box_iou_batch

## non_max_suppression

:::supervision.detection.utils.non_max_suppression

## polygon_to_mask

:::supervision.detection.utils.polygon_to_mask

## mask_to_xyxy

:::supervision.detection.utils.mask_to_xyxy

## mask_to_polygons

:::supervision.detection.utils.mask_to_polygons

## polygon_to_xyxy

:::supervision.detection.utils.polygon_to_xyxy

## filter_polygons_by_area

:::supervision.detection.utils.filter_polygons_by_area
