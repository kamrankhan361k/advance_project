## BoxAnnotator

:::supervision.detection.annotate.BoxAnnotator

## MaskAnnotator

:::supervision.detection.annotate.MaskAnnotator
