## PolygonZone

:::supervision.detection.tools.polygon_zone.PolygonZone

## PolygonZoneAnnotator

:::supervision.detection.tools.polygon_zone.PolygonZoneAnnotator
