## InferenceSlicer

:::supervision.detection.tools.inference_slicer.InferenceSlicer
