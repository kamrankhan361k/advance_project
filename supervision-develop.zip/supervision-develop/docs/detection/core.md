## Detections

:::supervision.detection.core.Detections
