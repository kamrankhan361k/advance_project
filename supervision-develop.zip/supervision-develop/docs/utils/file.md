## list_files_with_extensions

:::supervision.utils.file.list_files_with_extensions
