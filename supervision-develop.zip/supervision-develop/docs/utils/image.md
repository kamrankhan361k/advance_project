## ImageSink

:::supervision.utils.image.ImageSink

## crop

:::supervision.utils.image.crop_image
