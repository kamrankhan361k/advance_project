## plot_image

:::supervision.utils.notebook.plot_image

## plot_images_grid

:::supervision.utils.notebook.plot_images_grid
